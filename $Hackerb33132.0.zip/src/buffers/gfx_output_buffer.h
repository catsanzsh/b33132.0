#ifndef GFX_OUTPUT_BUFFER_H
#define GFX_OUTPUT_BUFFER_H

#include <PR/ultratypes.h>

extern u64 gGfxSPTaskOutputBuffer[0x2000];

#endif // GFX_OUTPUT_BUFFER_H
