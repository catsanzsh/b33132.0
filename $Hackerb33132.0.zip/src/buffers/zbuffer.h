#ifndef ZBUFFER_H
#define ZBUFFER_H

#include <PR/ultratypes.h>

#include "config.h"
#include "macros.h"

extern u16 gZBuffer[SCREEN_WIDTH * SCREEN_HEIGHT];

#endif // ZBUFFER_H
