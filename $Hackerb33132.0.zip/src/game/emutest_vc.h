#ifndef EMUTEST_VC_H
#define EMUTEST_VC_H

#include "types.h"

__attribute__((externally_visible))
extern f32 round_double_to_float(f64 v);

#endif
